import { CustomDirectiveDirective } from './custom-directive.directive';

describe('CustomDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
