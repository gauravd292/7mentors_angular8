import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular Demo';

  greetName:string = "Gaurav";
  greetMsg:string = "";
  
  factNumber: number = 1;
  factMsg:string = "";

  greet_data():void{
    this.greetMsg = "Hello " + this.greetName;
  }

  show_factorial():void{
    let factorial = 1;
    for(let i:number =  1; i <= this.factNumber; i++){
        factorial = factorial * i;
    }
    this.factMsg = "Factorial of  " + this.factNumber + " is : " + factorial;
  }

}
