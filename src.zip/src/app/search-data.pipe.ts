import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchData'
})
export class SearchDataPipe implements PipeTransform {

  transform(itemList: any[], searchText: string): any[] {
    if(!searchText) return itemList;
    if(!itemList) return [];

    // let newList = [];
    // itemList.forEach(item => {
    //     if((item.p_name).includes(searchText) != false)
    //     newList.push(item);
    // });
    // return newList;

    searchText = searchText.toLowerCase();
    return itemList.filter( it => {
      return (it.p_name).toLowerCase().includes(searchText);
    });

  }

}
