import { CalculateDiscountPipe } from './calculate-discount.pipe';

describe('CalculateDiscountPipe', () => {
  it('create an instance', () => {
    const pipe = new CalculateDiscountPipe();
    expect(pipe).toBeTruthy();
  });
});
