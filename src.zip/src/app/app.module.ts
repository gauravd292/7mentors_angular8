import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { StudentComponent } from './ComponentDemo/student.component';

import { EmployeeModule } from './employeeModule/employee.module';

import { ProductComponent } from './ComponentDemo/product.component';
import { StructralComponent } from './ComponentDemo/structural.component';
import { ForComponentComponent } from './for-component/for-component.component';
import { CrudComponentComponent } from './crud-component/crud-component.component';
import { AttrDirectiveComponent } from './attr-directive/attr-directive.component';
import { CustomDirectiveDirective } from './custom-directive.directive';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { PipeDemoComponent } from './pipe-demo/pipe-demo.component';
import { ExponentialStrengthPipe } from './exponential-strength.pipe';
import { CalculateDiscountPipe } from './calculate-discount.pipe';
import { SearchDataPipe } from './search-data.pipe';
import { ParentComponentComponent } from './parent-component/parent-component.component';
import { ChildComponentComponent } from './parent-component/child-component/child-component.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    ProductComponent,
    StructralComponent,
    ForComponentComponent,
    CrudComponentComponent,
    AttrDirectiveComponent,
    CustomDirectiveDirective,
    DataBindingComponent,
    PipeDemoComponent,
    ExponentialStrengthPipe,
    CalculateDiscountPipe,
    SearchDataPipe,
    ParentComponentComponent,
    ChildComponentComponent
  ],
  imports: [
  BrowserModule,
    FormsModule,
    EmployeeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
