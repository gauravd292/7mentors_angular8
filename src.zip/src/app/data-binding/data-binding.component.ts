import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {

  website: any;

  constructor() { 
    this.website = {
        srcData : "https://image.shutterstock.com/image-vector/grunge-red-sample-word-round-260nw-1242668641.jpg",
        description : "Demo Description",
        url : "http://localhost:4200/",
    };
  }

  ngOnInit(): void {
  }

}
