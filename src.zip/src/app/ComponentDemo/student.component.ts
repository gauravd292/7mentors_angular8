import { Component } from '@angular/core';

@Component({
    selector: 'app-student',
    templateUrl: './student.component.html',
    styleUrls: ['./student.component.css']
})

export class StudentComponent{

    roll_no: number;
    name: string;

    marks_1: number;
    marks_2: number;
    marks_3: number;
    
    marks: number[] = [];
    totalMarks: number = 0;
    grade: string = '';
    percentage: number = 0;

    show_result():void{

        // this.totalMarks = (this.marks_1) + (this.marks_2) + (this.marks_3);
        // this.percentage = (this.totalMarks/(3*100)) * 100;

        (this.marks).push(this.marks_1, this.marks_2, this.marks_3);
        for(let i:number = 0; i < this.marks.length; i++){
            this.totalMarks += this.marks[i];
        }
        this.percentage = (this.totalMarks/(this.marks.length*100)) * 100;

        if(this.percentage >= 60){
            this.grade = "A";
        }
        else{
            this.grade = "B";
        }
    }

}