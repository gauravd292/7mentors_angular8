import { Component } from '@angular/core';
import { element } from 'protractor';

@Component({
    selector: "app-structral",
    templateUrl : "./structural.component.html",
})

export class StructralComponent{

    blockNumber: boolean = false;

    numberArray: number[] = [10,20,30];
    stringArray: string[] = ["A1", "A2", "A3"];
    jsonObjArray: any = [{
        pid:101,
        pname:"Product 1",
        subArray: ["e11","e21","e31"]
    },
    {
        pid:102,
        pname:"Product 2",
        subArray: ["e12","e22","e32"]
    }];

}