import { Component } from '@angular/core';

@Component({
    selector: "app-product",
    templateUrl : "./product.component.html",
    styleUrls : ["./product.component.css"]
})

export class ProductComponent{
    pname:string;
    qty:number;
    price:number;
    discount:number = 0;
    finalPrice: number = 0;

    customers: any = [
        { code: '001', name: 'Name 1', gender: 'Male',  country: 'IN'},
        { code: '002', name: 'Name 2', gender: 'Female',  country: 'US'},
        { code: '003', name: 'Name 3', gender: 'Male',  country: 'UK'},
        { code: '004', name: 'Name 4', gender: 'Male',  country: 'UAE'},
    ];


    get_final_price():void{        
        this.finalPrice = this.price * this.qty;
        if(this.discount){
            this.finalPrice = this.finalPrice - this.discount;
        }
    }
}