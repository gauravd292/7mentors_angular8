import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'calculateDiscount'
})
export class CalculateDiscountPipe implements PipeTransform {

  transform(value: number, discount?: number): number {
    return value - (isNaN(discount) ? 0 : discount);
  }

}
