import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-component',
  templateUrl: './for-component.component.html',
  styleUrls: ['./for-component.component.css']
})
export class ForComponentComponent implements OnInit {

  productList: any;
  searchText: string = "";

  constructor() { }

  ngOnInit(): void {

    this.productList = [
      {p_id: "P1", p_name: "Product  1", maxQty: "30", unit_price: "20", discount: 0},
      {p_id: "P2", p_name: "Product Number 2", maxQty: "55", unit_price: "500", discount: 10},
      {p_id: "P3", p_name: "Product Number 3", maxQty: "40", unit_price: "80", discount: 0},
      {p_id: "P4", p_name: "Product  4", maxQty: "60", unit_price: "46", discount: 20},
      {p_id: "P5", p_name: "Product Number 5", maxQty: "100", unit_price: "159", discount: 0},
    ]

  }

}
