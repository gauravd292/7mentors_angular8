import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe-demo',
  templateUrl: './pipe-demo.component.html',
  styleUrls: ['./pipe-demo.component.css']
})
export class PipeDemoComponent implements OnInit {

  firstName: string = "first name Demo";
  lastName: string = "last name Demo";
  titleString: string = "title case Demo";

  jd: Date = new Date;

  num1: number = 0.60;
  num2: number = 1.456789;

  jsonObj: any = {
    code: "001",
    name: "Dummy",
    fees: 55000,
  }

  arrayObj: any = ["001", "Dummy", 55000, "sdfsdf", "456456"];

  constructor() { 
  }

  ngOnInit(): void {
  }

}
