import { SearchDataPipe } from './search-data.pipe';

describe('SearchDataPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchDataPipe();
    expect(pipe).toBeTruthy();
  });
});
