import { NgModule } from '@angular/core';
import { EmployeeComponent } from './employee.component';
import { FormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';

@NgModule({
    declarations: [EmployeeComponent],
    imports: [
    // BrowserModule,
    FormsModule
    ],
    exports: [EmployeeComponent]
})

export class EmployeeModule { }
  