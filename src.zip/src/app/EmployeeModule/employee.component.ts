import { Component } from '@angular/core';

@Component({
  selector: 'employee-emp-component',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {

    eid:string;
    ename:string;
    department:string;
    basic_salary:number = 0;
    net_salary: number;

    showTable:boolean=false;

    //-- in percentage (number/100)
    pf:number = 0.10;
    hra:number = 0.30;
    da:number = 0.15;

    calculate_net_salary(): void{
        this.net_salary = 
            this.basic_salary + 
            (this.basic_salary * this.pf) +
            (this.basic_salary * this.hra) +
            (this.basic_salary * this.da);

        this.showTable = true;
    }

}