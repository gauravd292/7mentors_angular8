import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-component',
  templateUrl: './crud-component.component.html',
  styleUrls: ['./crud-component.component.css']
})
export class CrudComponentComponent implements OnInit {

  productList: any = [];

  

  // productObj:any = {
  //   product_id: '',
  //   product_name: '',
  //   maximum_qty: '',
  //   price: ''
  // }

  productObj:any = {}

  index_to_opearate: number = -1;
  show_table: boolean = true;

  constructor() { 
    this.show_table = true;
  }

  ngOnInit(): void {

    this.productList = [
      {product_id: "P1", product_name: "Product Number 1", maximum_qty: "30", price: "20"},
      {product_id: "P2", product_name: "Product Number 2", maximum_qty: "55", price: "500"},
      {product_id: "P3", product_name: "Product Number 3", maximum_qty: "40", price: "80"}
    ];

  }

  saveProduct(): void{
    if(this.index_to_opearate == -1){
      (this.productList).push(this.productObj);
    }
    else{
      this.productList[this.index_to_opearate] = this.productObj;
    }
    this.productObj = {};
    this.show_table = true;
  }

  updateProduct(index: number): void{
    this.productObj = this.productList[index];
    this.productList[index] = {};
    this.index_to_opearate = index;
    this.show_table = false;
  }

  deleteProduct(index: number): void{
    (this.productList).splice(index, 1);
  }

}
